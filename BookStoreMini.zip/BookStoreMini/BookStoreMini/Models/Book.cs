﻿using Microsoft.Data.SqlClient;
using System.Data;
using System.Drawing;

namespace BookStoreMini.Models
{
    public class Book
    {
        public int BookId { get; set; }
        public string Title { get; set; }
        public string Category { get; set; }
        public int Price { get; set; }
        public int Pages { get; set; }
        public string Author { get; set; }
        public string BookStatus { get; set; }

        public static List<Book> GetAllBooks()
        {
            List<Book> lstbk = new List<Book>();
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\ProjectModels;Initial Catalog=KTjune23;Integrated Security=True";

            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Select * from Books";
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                    lstbk.Add(new Book {BookId = dr.GetInt32(0),
                        Title = dr.GetString(1), Category = dr.GetString(2),
                        Price = dr.GetInt32(3), Pages = dr.GetInt32(4),
                        Author = dr.GetString(5), BookStatus = dr.GetString(6)
                    });
                dr.Close();
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                cn.Close();
            }
            return lstbk;
            }

        public static Book GetSingleBook(int BookId)
        {
            Book obj = new Book();
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\ProjectModels;Initial Catalog=KTjune23;Integrated Security=True";
            cn.Open();
            try
            {
                //SqlCommand cmd = cn.CreateCommand();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from Books where BookId = @BookId";
                cmd.Parameters.AddWithValue("@BookId", BookId);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    obj.BookId = BookId;
                    obj.Title = dr.GetString("Title");
                    obj.Category = dr.GetString("Category");
                    obj.Price = dr.GetInt32("Price");
                    obj.Pages = dr.GetInt32("Pages");
                    obj.Author = dr.GetString("Author");
                    obj.BookStatus = dr.GetString("BookStatus");
                }
                else
                {
                    //not found
                    obj = null;
                }
            dr.Close();
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                cn.Close();
            }
            return obj;
        }

        public static void InsertBook(Book obj)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\ProjectModels;Initial Catalog=KTjune23;Integrated Security=True";
            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Insert into Books values(@BookId, @Title, @Category, @Price, @Pages, @Author, @BookStatus)";
                cmd.Parameters.AddWithValue("@BookId", obj.BookId);
                cmd.Parameters.AddWithValue("@Title", obj.Title);
                cmd.Parameters.AddWithValue("@Category", obj.Category);
                cmd.Parameters.AddWithValue("@Price", obj.Price);
                cmd.Parameters.AddWithValue("@Pages", obj.Pages);
                cmd.Parameters.AddWithValue("@Author", obj.Author);
                cmd.Parameters.AddWithValue("@BookStatus", obj.BookStatus);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                cn.Close();
            }
        }

        public static void UpdateBook(Book obj)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\ProjectModels;Initial Catalog=KTjune23;Integrated Security=True";
            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Update Books set Title=@Title, Category=@Category, Price=@Price, Pages=@Pages, Author=@Author, BookStatus=@BookStatus where BookId = @BookId";
                cmd.Parameters.AddWithValue("@BookId", obj.BookId);
                cmd.Parameters.AddWithValue("@Title", obj.Title);
                cmd.Parameters.AddWithValue("@Category", obj.Category);
                cmd.Parameters.AddWithValue("@Price", obj.Price);
                cmd.Parameters.AddWithValue("@Pages", obj.Pages);
                cmd.Parameters.AddWithValue("@Author", obj.Author);
                cmd.Parameters.AddWithValue("@BookStatus", obj.BookStatus);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                cn.Close();
            }
        }

        public static void DeleteBook(int BookId)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\ProjectModels;Initial Catalog=KTjune23;Integrated Security=True";
            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Delete from Books where BookId = @BookId";
                cmd.Parameters.AddWithValue("@BookId", BookId);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                cn.Close();
            }
        }
    }
}
