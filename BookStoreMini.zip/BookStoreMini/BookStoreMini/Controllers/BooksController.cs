﻿using BookStoreMini.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BookStoreMini.Controllers
{
    public class BooksController : Controller
    {
        // GET: BooksController
        public ActionResult Index()
        {
            List<Book> lst = Book.GetAllBooks();
            return View(lst);
        }

        // GET: BooksController/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
                return NotFound();
            Book obj = Book.GetSingleBook(id.Value);
            return View(obj);

        }

        // GET: BooksController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: BooksController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Book obj)
        {
            try
            {
                Book.InsertBook(obj);
                ViewBag.message = "Success !!!";
                return View();
                //return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.message = ex.Message;
                return View();
            }
        }

        // GET: BooksController/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
                return NotFound();
            Book obj = Book.GetSingleBook(id.Value);
            return View(obj);
        }

        // POST: BooksController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Book obj, int id, IFormCollection collection)
        {
            try
            {
                Book.UpdateBook(obj);
                ViewBag.message = "Updated Successfully";
                return View();
                //return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.message = ex.Message;
                return View();
            }
        }

        // GET: BooksController/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
                return NotFound();
            Book obj = Book.GetSingleBook(id.Value);
            return View(obj);
        }

        // POST: BooksController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                Book.DeleteBook(id);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
